# Build A Habit Tracker For Daily

Full-stack app generated from: "Build a habit tracker for daily workouts"

## Run

```bash
npm install
npm run dev
```

Backend: http://localhost:5050
Frontend: http://localhost:3001

## Notes
- This export is a single-entity CRUD app generated from a spec.
- Set NEXT_PUBLIC_BACKEND_URL if you change backend port.
