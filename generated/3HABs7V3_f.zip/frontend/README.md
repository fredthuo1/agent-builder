# build-a-task-app-with-auth-and-s — Frontend

## Run
```bash
npm install
npm run dev
```

Frontend runs on: http://localhost:3001

## Backend URL
Copy `.env.example` to `.env` (optional) and set:

NEXT_PUBLIC_BACKEND_URL=http://localhost:5050
