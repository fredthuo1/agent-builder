# Build A Task App With Auth And S

Full-stack app generated from: "Build a task app with auth and sqlite"

## Run

```bash
npm install
npm run dev
```

Backend: http://localhost:5050  
Frontend: http://localhost:3001
