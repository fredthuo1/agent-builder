# build-a-task-app-with-au Frontend

```bash
npm i
npm run dev
```
