# build-a-task-app-with-au Backend

```bash
npm i
npm run dev
```
