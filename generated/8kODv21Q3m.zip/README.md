# Build An Ecommerce App

Full-stack app generated from: "Build an eCommerce app"

## Run

```bash
npm install
npm run dev
```

Backend: http://localhost:5050
Frontend: http://localhost:3001
