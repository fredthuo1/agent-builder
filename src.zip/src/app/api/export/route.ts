import fs from "fs";
import fsp from "fs/promises";
import path from "path";
import archiver from "archiver";
import { getBuild } from "@/lib/builds";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const buildId = String(searchParams.get("buildId") || "");

  if (!buildId) return new Response("Missing buildId", { status: 400 });

  const build = getBuild(buildId);
  if (!build) return new Response("Unknown buildId", { status: 404 });

  // Create zip into memory stream -> Response
  const zipName = `${buildId}.zip`;

  const headers = new Headers();
  headers.set("Content-Type", "application/zip");
  headers.set("Content-Disposition", `attachment; filename="${zipName}"`);

  const stream = new TransformStream();
  const writable = stream.writable.getWriter();

  // archiver expects a Node stream; we bridge via a PassThrough
  const { PassThrough } = await import("stream");
  const pass = new PassThrough();

  const archive = archiver.default("zip", { zlib: { level: 9 } });

  archive.on("error", async (err: any) => {
    try {
      pass.destroy(err);
      await writable.abort(err);
    } catch {}
  });

  archive.pipe(pass);

  // exclude heavy dirs if present
  archive.glob("**/*", {
    cwd: build.outDir,
    dot: true,
    ignore: ["**/node_modules/**", "**/.next/**", "**/.git/**", "**/backend/data/**"],
  });

  // stream pass -> web writable
  pass.on("data", async (chunk: Buffer) => {
    await writable.write(chunk);
  });

  pass.on("end", async () => {
    await writable.close();
  });

  // if build isn't done, still export what exists (useful for debugging)
  await archive.finalize();

  return new Response(stream.readable, { headers });
}