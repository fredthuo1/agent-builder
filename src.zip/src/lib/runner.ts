﻿import fs from "fs/promises";
import path from "path";
import {
  appendLog,
  ensureGeneratedRoot,
  rmrf,
  safeWriteText,
  setAgentStatus,
  setBuildDone,
  setBuildFailed,
  setBuildStatus,
} from "./builds";
import type { GenerationMode } from "./types";
import { makePlanWithGemini } from "./planner.gemini";
import { backendFiles, frontendFiles, rootFiles } from "./templates";

async function ensureDir(p: string) {
  await fs.mkdir(p, { recursive: true });
}

async function writeFiles(outDir: string, files: Record<string, string>) {
  for (const [rel, content] of Object.entries(files)) {
    const full = path.join(outDir, rel);
    await ensureDir(path.dirname(full));
    await safeWriteText(full, content);
  }
}

export async function runBuild(buildId: string, prompt: string, outDir: string, modeRequested: GenerationMode) {
  try {
    await ensureGeneratedRoot();
    await rmrf(outDir);
    await ensureDir(outDir);

    await setBuildStatus(buildId, "running");

    // 🧠 Planner
    await setAgentStatus(buildId, "planner", "running");
    await appendLog(buildId, "planner", `Planning app for: "${prompt}"`);
    await appendLog(buildId, "planner", `Mode requested: ${modeRequested}`);

    const plan = await makePlanWithGemini(prompt, modeRequested);
    await appendLog(buildId, "planner", `Planner mode used: ${plan.generationMode}`);
    await appendLog(buildId, "planner", `App name: ${plan.appName}`);
    await appendLog(buildId, "planner", `Entities: ${plan.entities.length}`);
    await setAgentStatus(buildId, "planner", "done", { plan, generationMode: plan.generationMode });

    // 🏗 Backend
    await setAgentStatus(buildId, "backend", "running");
    await appendLog(buildId, "backend", "Generating Express + SQLite backend (schema-driven CRUD)...");
    await writeFiles(outDir, backendFiles(plan));
    await appendLog(buildId, "backend", "Backend files written ✅");
    await setAgentStatus(buildId, "backend", "done");

    // 🎨 Frontend
    await setAgentStatus(buildId, "frontend", "running");
    await appendLog(buildId, "frontend", "Generating Next.js frontend (spec-driven UI)...");
    await writeFiles(outDir, frontendFiles(plan));
    await appendLog(buildId, "frontend", "Frontend files written ✅");
    await setAgentStatus(buildId, "frontend", "done");

    // 🧪 QA
    await setAgentStatus(buildId, "qa", "running");
    await appendLog(buildId, "qa", "Writing root package + README + spec.json...");
    await writeFiles(outDir, rootFiles(plan));
    await appendLog(buildId, "qa", "Root files written ✅");
    await appendLog(buildId, "qa", "Build done ✅");
    await setAgentStatus(buildId, "qa", "done");

    await setBuildDone(buildId);
  } catch (e: any) {
    console.error("Build failed:", e);
    await setBuildFailed(buildId, e?.message || "Unknown error");
    await setAgentStatus(buildId, "qa", "failed");
  }
}